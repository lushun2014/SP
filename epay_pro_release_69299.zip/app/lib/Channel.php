<?php

namespace app\lib;

use think\facade\Db;

class Channel
{

	public static function get($id, $channelinfo = null)
	{
		$value = Db::name('channel')->where('id', $id)->find();
		if (!$value) return null;
		$channel = ['id' => $value['id'], 'name' => $value['name'], 'mode' => $value['mode'], 'type' => $value['type'], 'plugin' => $value['plugin'], 'apptype' => $value['apptype'], 'appwxmp' => $value['appwxmp'], 'appwxa' => $value['appwxa'], 'costrate' => $value['costrate'], 'daytop' => $value['daytop'], 'daymaxorder' => $value['daymaxorder']];

		$config = json_decode($value['config'], true);
		if (!empty($channelinfo) && !empty($config) && is_array($config)) {
			$arr = json_decode($channelinfo, true);
			if (is_array($arr)) {
				foreach ($config as $configkey => $configrow) {
					if ($configrow && substr($configrow, 0, 1) == '[') {
						$key = substr($configrow, 1, -1);
						$config[$configkey] = isset($arr[$key]) ? $arr[$key] : $configrow;
					}
				}
			}
		}

		if (!empty($config)) {
			$channel = array_merge($channel, $config);
		}
		return $channel;
	}

	public static function getSub($id)
	{
		$value = Db::name('subchannel')->alias('B')->join('channel A', 'B.channel=A.id')->where('B.id', $id)->field('A.*,B.info,B.id subid,B.name subname')->find();
		if (!$value) return null;
		$channel = ['id' => $value['id'], 'subid' => $value['subid'], 'name' => $value['name'], 'subname' => $value['subname'], 'mode' => $value['mode'], 'type' => $value['type'], 'plugin' => $value['plugin'], 'apptype' => $value['apptype'], 'appwxmp' => $value['appwxmp'], 'appwxa' => $value['appwxa'], 'costrate' => $value['costrate'], 'daytop' => $value['daytop'], 'daymaxorder' => $value['daymaxorder']];

		$config = json_decode($value['config'], true);
		if (!empty($value['info']) && !empty($config) && is_array($config)) {
			$arr = json_decode($value['info'], true);
			if (is_array($arr)) {
				foreach ($config as $configkey => $configrow) {
					if ($configrow && substr($configrow, 0, 1) == '[') {
						$key = substr($configrow, 1, -1);
						$config[$configkey] = isset($arr[$key]) ? $arr[$key] : $configrow;
					}
				}
			}
			if (isset($arr['apptype']) && !empty($arr['apptype'])) {
				$channel['apptype'] = $arr['apptype'];
			}
			if (isset($arr['appwxmp']) && $arr['appwxmp'] > 0) {
				$channel['appwxmp'] = $arr['appwxmp'];
				$channel['subappwxmp'] = 1;
			}
			if (isset($arr['appwxa']) && $arr['appwxa'] > 0) {
				$channel['appwxa'] = $arr['appwxa'];
				$channel['subappwxa'] = 1;
			}
		}
		if (!empty($config)) {
			$channel = array_merge($channel, $config);
		}
		return $channel;
	}

	public static function getGroup($gid)
	{
		$group = Db::name('group')->where('gid', $gid)->find();
		if (!$group) $group = Db::name('group')->where('gid', 0)->find();
		$info = json_decode($group['info'] ?? '{}', true);
		if (!is_array($info)) $info = [];

		$rows = Db::name('type')->where('status', 1)->field('id,name')->select();
		$paytype = [];
		foreach ($rows as $row) {
			$paytype[$row['id']] = $row['name'];
		}

		$subchannel_type = [];
		$subchannel_type_ids = [];
		foreach ($info as $id => $row) {
			if (!isset($paytype[$id]) || !is_array($row)) continue;
			if ((int) ($row['channel'] ?? 0) == -2) {
				$subchannel_type[] = $paytype[$id];
				$subchannel_type_ids[] = $id;
			}
		}
		$group['subchannel_type'] = $subchannel_type;
		$group['subchannel_type_ids'] = $subchannel_type_ids;
		return $group;
	}

	public static function info($id, $gid = 0)
	{
		$value = Db::name('channel')->where('id', $id)->field('id,plugin,type,rate,apptype,mode,paymin,paymax')->find();
		if (!$value) return null;
		$money_rate = $value['rate'] ?? 0;
		if ($gid > 0) $groupinfo = Db::name('group')->where('gid', $gid)->value('info');
		if (empty($groupinfo)) $groupinfo = Db::name('group')->where('gid', 0)->value('info');
		if ($groupinfo) {
			$info = json_decode($groupinfo, true);
			if (is_array($info) && isset($info[$value['type']])) {
				$groupinfo = $info[$value['type']];
				if (is_array($groupinfo) && isset($groupinfo['rate']) && $groupinfo['rate'] !== '') {
					$money_rate = $groupinfo['rate'];
				}
			}
		}
		return ['typeid' => $value['type'], 'plugin' => $value['plugin'], 'channel' => $value['id'], 'subchannel' => 0, 'rate' => $money_rate, 'apptype' => $value['apptype'], 'mode' => $value['mode'], 'paymin' => $value['paymin'], 'paymax' => $value['paymax']];
	}

	public static function getWeixin($id)
	{
		$value = Db::name('weixin')->where('id', $id)->find();
		return $value;
	}

	// 支付提交处理（输入支付方式名称）
	public static function submit($type, $uid = 0, $gid = 0, $money = 0, $sub_mch_id = 0, $sub_channel_id = 0, $is_mobile = false)
	{
		if ($is_mobile) {
			$paytype = Db::name('type')->where('name', $type)->whereRaw('(device=0 OR device=2)')->field('id,name,status')->find();
		} else {
			$paytype = Db::name('type')->where('name', $type)->whereRaw('(device=0 OR device=1)')->field('id,name,status')->find();
		}
		if (!$paytype || $paytype['status'] == 0) return null;
		$typeid = $paytype['id'];
		$typename = $paytype['name'];

		return self::getSubmitInfo($typeid, $typename, $uid, $gid, $money, $sub_mch_id, $sub_channel_id);
	}

	// 支付提交处理2（输入支付方式ID）
	public static function submit2($typeid, $uid = 0, $gid = 0, $money = 0)
	{
		$paytype = Db::name('type')->where('id', $typeid)->field('id,name,status')->find();
		if (!$paytype || $paytype['status'] == 0) return null;
		$typename = $paytype['name'];

		return self::getSubmitInfo($typeid, $typename, $uid, $gid, $money);
	}

	//获取通道、插件、费率信息
	public static function getSubmitInfo($typeid, $typename, $uid, $gid, $money, $sub_mch_id = 0, $sub_channel_id = 0)
	{
		if ($gid > 0) $groupinfo = Db::name('group')->where('gid', $gid)->value('info');
		if (empty($groupinfo)) $groupinfo = Db::name('group')->where('gid', 0)->value('info');
		if ($groupinfo) {
			$info = json_decode($groupinfo, true);
			if (isset($info[$typeid]) && is_array($info[$typeid])) {
				$channel = $info[$typeid]['channel'];
				$money_rate = $info[$typeid]['rate'];
				$is_roll = isset($info[$typeid]['type']) && $info[$typeid]['type'] == 'roll';
			} else {
				$channel = -1;
				$money_rate = null;
				$is_roll = false;
			}
			if ($channel == 0) { //当前商户关闭该通道
				return false;
			} elseif ($channel == -1) { //随机可用通道
				$rows = Db::name('channel')->where('type', $typeid)->where('status', 1)->where('daystatus', 0)->field('id,plugin,status,rate,apptype,mode,paymin,paymax,timestart,timestop')->order('id', 'asc')->select();
				if (count($rows) > 0) {
					$newrows = [];
					foreach ($rows as $row) {
						if ($money > 0 && !empty($row['paymin']) && $row['paymin'] > 0 && $money < $row['paymin']) continue;
						if ($money > 0 && !empty($row['paymax']) && $row['paymax'] > 0 && $money > $row['paymax']) continue;
						if (!isNullOrEmpty($row['timestart']) && !isNullOrEmpty($row['timestop']) && ($row['timestart'] > 0 || $row['timestop'] > 0)) {
							$hour = date('H');
							if ($row['timestart'] < $row['timestop']) {
								if ($hour < $row['timestart'] || $hour > $row['timestop']) continue;
							} else {
								if ($hour < $row['timestart'] && $hour > $row['timestop']) continue;
							}
						}
						$newrows[] = $row;
					}
					if (count($newrows) > 0) {
						$row = $newrows[array_rand($newrows)];
					} else {
						$row = $rows[array_rand($rows)];
					}
					if (empty($money_rate)) $money_rate = $row['rate'];
					return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $row['id'], 'subchannel' => 0, 'rate' => $money_rate, 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax']];
				}
			} elseif ($channel == -4) { //顺序可用通道
				$rows = Db::name('channel')->where('type', $typeid)->where('status', 1)->where('daystatus', 0)->field('id,plugin,status,rate,apptype,mode,paymin,paymax,timestart,timestop')->order('id', 'asc')->select();
				if (count($rows) > 0) {
					$newrows = [];
					foreach ($rows as $row) {
						if ($money > 0 && !empty($row['paymin']) && $row['paymin'] > 0 && $money < $row['paymin']) continue;
						if ($money > 0 && !empty($row['paymax']) && $row['paymax'] > 0 && $money > $row['paymax']) continue;
						if (!isNullOrEmpty($row['timestart']) && !isNullOrEmpty($row['timestop']) && ($row['timestart'] > 0 || $row['timestop'] > 0)) {
							$hour = date('H');
							if ($row['timestart'] < $row['timestop']) {
								if ($hour < $row['timestart'] || $hour > $row['timestop']) continue;
							} else {
								if ($hour < $row['timestart'] && $hour > $row['timestop']) continue;
							}
						}
						$newrows[] = $row;
					}
					if (count($newrows) == 0) return false;
					$index = Db::name('group')->where('gid', $gid)->value('index');
					$index = $index % count($newrows);
					$row = $newrows[$index];
					$index = ($index + 1) % count($newrows);
					Db::name('group')->where('gid', $gid)->update(['index' => $index]);
					if (empty($money_rate)) $money_rate = $row['rate'];
					return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $row['id'], 'subchannel' => 0, 'rate' => $money_rate, 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax']];
				}
			} elseif ($channel == -5) { //首个可用通道
				$rows = Db::name('channel')->where('type', $typeid)->where('status', 1)->where('daystatus', 0)->field('id,plugin,status,rate,apptype,mode,paymin,paymax,timestart,timestop')->order('id', 'asc')->select();
				if (count($rows) > 0) {
					$newrows = [];
					foreach ($rows as $row) {
						if ($money > 0 && !empty($row['paymin']) && $row['paymin'] > 0 && $money < $row['paymin']) continue;
						if ($money > 0 && !empty($row['paymax']) && $row['paymax'] > 0 && $money > $row['paymax']) continue;
						if (!isNullOrEmpty($row['timestart']) && !isNullOrEmpty($row['timestop']) && ($row['timestart'] > 0 || $row['timestop'] > 0)) {
							$hour = date('H');
							if ($row['timestart'] < $row['timestop']) {
								if ($hour < $row['timestart'] || $hour > $row['timestop']) continue;
							} else {
								if ($hour < $row['timestart'] && $hour > $row['timestop']) continue;
							}
						}
						$newrows[] = $row;
					}
					if (count($newrows) == 0) return false;
					$row = $newrows[0];
					if (empty($money_rate)) $money_rate = $row['rate'];
					return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $row['id'], 'subchannel' => 0, 'rate' => $money_rate, 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax']];
				}
			} elseif ($channel == -2) { //用户自定义子通道
				$query = Db::name('subchannel')->alias('B')->join('channel A', 'B.channel=A.id')->where('B.uid', $uid)->where('A.type', $typeid)->where('A.status', 1)->where('B.status', 1)->where('A.daystatus', 0)->field('A.id,plugin,A.status,rate,apptype,mode,paymin,paymax,B.id subid,timestart,timestop')->order('B.usetime', 'asc');
				if ($sub_mch_id > 0) $query = $query->where('B.apply_id', $sub_mch_id);
				if ($sub_channel_id > 0) $query = $query->where('B.id', $sub_channel_id);
				$rows = $query->select();
				if (count($rows) > 0) {
					$newrows = [];
					foreach ($rows as $row) {
						if ($money > 0 && !empty($row['paymin']) && $row['paymin'] > 0 && $money < $row['paymin']) continue;
						if ($money > 0 && !empty($row['paymax']) && $row['paymax'] > 0 && $money > $row['paymax']) continue;
						if (!isNullOrEmpty($row['timestart']) && !isNullOrEmpty($row['timestop']) && ($row['timestart'] > 0 || $row['timestop'] > 0)) {
							$hour = date('H');
							if ($row['timestart'] < $row['timestop']) {
								if ($hour < $row['timestart'] || $hour > $row['timestop']) continue;
							} else {
								if ($hour < $row['timestart'] && $hour > $row['timestop']) continue;
							}
						}
						$newrows[] = $row;
					}
					if (count($newrows) > 0) {
						$row = $newrows[0];
					} else {
						$row = $rows[0];
					}
					if (empty($money_rate)) $money_rate = $row['rate'];
					Db::name('subchannel')->where('id', $row['subid'])->update(['usetime' => date('Y-m-d H:i:s')]);
					return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $row['id'], 'subchannel' => $row['subid'], 'rate' => $money_rate, 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax']];
				}
			} elseif ($channel == -3) { //随机可用轮询组
				$rows = Db::name('roll')->where('type', $typeid)->where('status', 1)->limit(1)->select();
				if (count($rows) > 0) {
					$row = $rows[array_rand($rows)];
					$is_roll = true;
					$channel = $row['id'];
					goto ROLL_START;
				}
				return false;
			} else {
				ROLL_START:
				if ($is_roll) { //解析轮询组
					$channel = self::getChannelFromRoll($channel, $money);
					if (!$channel || $channel == 0) { //当前轮询组未开启
						return false;
					}
				}
				//获取轮询组对应通道
				$row = Db::name('channel')->where('id', $channel)->field('plugin,status,rate,apptype,mode,paymin,paymax,timestart,timestop')->find();
				if (!$row) return false;
				if (empty($money_rate)) $money_rate = $row['rate'];
				return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $channel, 'subchannel' => 0, 'rate' => $money_rate, 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax'], 'timestart' => $row['timestart'], 'timestop' => $row['timestop']];
			}
		} else {
			//未设置用户组
			$row = Db::name('channel')->where('type', $typeid)->where('status', 1)->where('daystatus', 0)->field('id,plugin,status,rate,apptype,mode,paymin,paymax,timestart,timestop')->orderRaw('rand()')->find();
			if ($row) {
				return ['typeid' => $typeid, 'typename' => $typename, 'plugin' => $row['plugin'], 'channel' => $row['id'], 'subchannel' => 0, 'rate' => $row['rate'], 'apptype' => $row['apptype'], 'mode' => $row['mode'], 'paymin' => $row['paymin'], 'paymax' => $row['paymax'], 'timestart' => $row['timestart'], 'timestop' => $row['timestop']];
			}
		}
		return false;
	}

	// 获取当前商户可用支付方式
	public static function getTypes($uid, $gid = 0)
	{
		if (checkmobile() == true) {
			$rows = Db::name('type')->where('status', 1)->whereRaw('(device=0 OR device=2)')->order('id', 'asc')->select();
		} else {
			$rows = Db::name('type')->where('status', 1)->whereRaw('(device=0 OR device=1)')->order('id', 'asc')->select();
		}
		$paytype = [];
		foreach ($rows as $row) {
			$paytype[$row['id']] = $row;
		}
		if ($gid > 0) $groupinfo = Db::name('group')->where('gid', $gid)->value('info');
		if (empty($groupinfo)) $groupinfo = Db::name('group')->where('gid', 0)->value('info');
		if ($groupinfo) {
			$info = json_decode($groupinfo, true);
			foreach ($info as $id => $row) {
				if (!isset($paytype[$id])) continue;
				if ($row['channel'] == 0) {
					unset($paytype[$id]);
				} elseif ($row['channel'] == -1 || $row['channel'] == -4 || $row['channel'] == -5) {
					$channel = Db::name('channel')->where('type', $id)->where('status', 1)->field('rate,status')->find();
					if (!$channel) {
						unset($paytype[$id]);
					} elseif (empty($row['rate'])) {
						$paytype[$id]['rate'] = $channel['rate'];
					} else {
						$paytype[$id]['rate'] = $row['rate'];
					}
				} elseif ($row['channel'] == -2) {
					$channel = Db::name('subchannel')->alias('B')->join('channel A', 'B.channel=A.id')->where('B.uid', $uid)->where('A.type', $id)->where('A.status', 1)->where('B.status', 1)->field('A.id,A.status,rate')->find();
					if (!$channel) {
						unset($paytype[$id]);
					} elseif (empty($row['rate'])) {
						$paytype[$id]['rate'] = $channel['rate'];
					} else {
						$paytype[$id]['rate'] = $row['rate'];
					}
				} elseif ($row['channel'] == -3) {
					$channel = Db::name('roll')->where('type', $id)->where('status', 1)->field('id,status')->find();
					if (!$channel) {
						unset($paytype[$id]);
					} else {
						$paytype[$id]['rate'] = $row['rate'];
					}
				} else {
					if ($row['type'] == 'roll') {
						$status = Db::name('roll')->where('id', $row['channel'])->value('status');
					} else {
						$status = Db::name('channel')->where('id', $row['channel'])->value('status');
						if (empty($row['rate'])) $row['rate'] = Db::name('channel')->where('id', $row['channel'])->value('rate');
					}
					if (!$status || $status == 0) unset($paytype[$id]);
					else $paytype[$id]['rate'] = $row['rate'];
				}
			}
		} else {
			foreach ($paytype as $id => $row) {
				$status = Db::name('channel')->where('type', $id)->where('status', 1)->value('status');
				if (!$status || $status == 0) unset($paytype[$id]);
				else {
					$paytype[$id]['rate'] = Db::name('channel')->where('type', $id)->where('status', 1)->value('rate');
				}
			}
		}
		return $paytype;
	}

	//根据轮询组ID获取支付通道ID
	static private function getChannelFromRoll($channel, $money)
	{
		$row = Db::name('roll')->where('id', $channel)->find();
		if ($row['status'] == 1) {
			$info = self::rollinfo_decode($row['info'], true);

			//先根据支付金额与限额过滤可用支付通道
			$channelids = [];
			foreach ($info as $inforow) {
				$channelids[] = $inforow['name'];
			}
			$rows = Db::name('channel')->whereIn('id', $channelids)->where('status', 1)->where('daystatus', 0)->field('id,paymin,paymax,timestart,timestop')->select();
			$newids = [];
			foreach ($rows as $channelrow) {
				if ($money > 0 && !empty($channelrow['paymin']) && $channelrow['paymin'] > 0 && $money < $channelrow['paymin']) continue;
				if ($money > 0 && !empty($channelrow['paymax']) && $channelrow['paymax'] > 0 && $money > $channelrow['paymax']) continue;
				if (!isNullOrEmpty($channelrow['timestart']) && !isNullOrEmpty($channelrow['timestop']) && ($channelrow['timestart'] > 0 || $channelrow['timestop'] > 0)) {
					$hour = date('H');
					if ($channelrow['timestart'] < $channelrow['timestop']) {
						if ($hour < $channelrow['timestart'] || $hour > $channelrow['timestop']) continue;
					} else {
						if ($hour < $channelrow['timestart'] && $hour > $channelrow['timestop']) continue;
					}
				}
				$newids[] = $channelrow['id'];
			}
			if (count($newids) == 0) return false;

			$newinfo = [];
			foreach ($info as $inforow) {
				if (in_array($inforow['name'], $newids)) $newinfo[] = $inforow;
			}

			if ($row['kind'] == 2) {
				return $newids[0];
			} elseif ($row['kind'] == 1) {
				$channel = self::random_weight($newinfo);
			} else {
				$index = $row['index'] % count($newinfo);
				$channel = $newinfo[$index]['name'];
				$index = ($row['index'] + 1) % count($newinfo);
				Db::name('roll')->where('id', $row['id'])->update(['index' => $index]);
			}
			return $channel;
		}
		return false;
	}

	//解析轮询组info
	static private function rollinfo_decode($content)
	{
		$result = [];
		$arr = explode(',', $content);
		foreach ($arr as $row) {
			if (empty($row)) continue;
			$a = explode(':', $row);
			$result[] = ['name' => (int) ($a[0] ?? 0), 'weight' => (int) ($a[1] ?? 0)];
		}
		return $result;
	}

	//加权随机
	static private function random_weight($arr)
	{
		$weightSum = 0;
		foreach ($arr as $value) {
			$weightSum += intval($value['weight']);
		}
		if ($weightSum <= 0) return false;
		$randNum = mt_rand(1, $weightSum);
		foreach ($arr as $v) {
			if ($randNum <= $v['weight']) {
				return $v['name'];
			}
			$randNum -= $v['weight'];
		}
	}

	static private function in_range($range, $money)
	{
		if (empty($range)) return true;
		$range = explode(',', $range);
		foreach ($range as $row) {
			if (strpos($row, '-') !== false) {
				$minmax = explode('-', $row);
				if ($money >= intval($minmax[0]) && $money <= intval($minmax[1])) {
					return true;
				}
			} else {
				if ($money == intval($row)) {
					return true;
				}
			}
		}
		return false;
	}
}
