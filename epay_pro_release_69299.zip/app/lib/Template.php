<?php

namespace app\lib;

use think\facade\View;

class Template
{

	private static $templateTypes = [
		'home' => '首页模板',
		'pay' => '支付页模板',
		'qrpay' => '聚合收款页模板',
	];

	public static function getTypes(): array
	{
		return self::$templateTypes;
	}

	public static function getTemplateList(string $type): array
	{
		if (!isset(self::$templateTypes[$type])) {
			return [];
		}
		$dir = TEMPLATE_ROOT . $type . DIRECTORY_SEPARATOR;
		if (!is_dir($dir)) {
			return [];
		}
		$list = [];
		$handle = opendir($dir);
		if ($handle === false) {
			return [];
		}
		while (false !== ($file = readdir($handle))) {
			if ($file === '.' || $file === '..' || strpos($file, '.') !== false) {
				continue;
			}
			$templateDir = $dir . $file . DIRECTORY_SEPARATOR;
			if (!is_dir($templateDir)) {
				continue;
			}
			$infoFile = $templateDir . 'info.json';
			$info = [
				'name' => $file,
				'title' => $file,
				'author' => '未知',
				'version' => '1.0',
				'preview' => '',
			];
			if (is_file($infoFile)) {
				$json = json_decode(file_get_contents($infoFile), true);
				if (is_array($json)) {
					$info['title'] = $json['title'] ?? $file;
					$info['author'] = $json['author'] ?? '未知';
					$info['version'] = $json['version'] ?? '1.0';
					if (!empty($json['inputs']) && is_array($json['inputs'])) {
						$info['has_config'] = true;
					}
				}
			}
			$previewFile = $templateDir . 'preview.png';
			if (is_file($previewFile)) {
				$info['preview'] = '/template/' . $type . '/' . $file . '/preview.png';
			}
			$list[] = $info;
		}
		closedir($handle);
		return $list;
	}

	public static function getAllTemplateList(): array
	{
		$result = [];
		foreach (self::$templateTypes as $type => $label) {
			$result[$type] = [
				'label' => $label,
				'configKey' => 'template_' . $type,
				'list' => self::getTemplateList($type),
			];
		}
		return $result;
	}

	public static function getHomeFilePath($name = 'index')
	{
		$template = config_get('template_home', 'default');
		return self::getFilePath('home', $template, $name);
	}

	public static function getPayFilePath($name = 'index')
	{
		$template = config_get('template_pay', 'default');
		return self::getFilePath('pay', $template, $name);
	}
	
	public static function getQrpayFilePath($name = 'index')
	{
		$template = config_get('template_qrpay', 'default');
		return self::getFilePath('qrpay', $template, $name);
	}

	public static function getFilePath($type, $template, $name = 'index')
	{
		$filename = TEMPLATE_ROOT . $type . DIRECTORY_SEPARATOR . $template . DIRECTORY_SEPARATOR . $name . '.html';
		if (!is_file($filename) && $template != 'default') {
			return self::getFilePath($type, 'default', $name);
		} elseif (!is_file($filename)) {
			return 'index/404';
		}
		View::assign('template_path', '/template/' . $type . '/' . $template . '/');
		View::engine()->config([
			'view_path' => TEMPLATE_ROOT . $type . DIRECTORY_SEPARATOR . $template . DIRECTORY_SEPARATOR,
			'default_filter' => 'raw',
		]);
		$params = plugin_config_get('template', $type . '_' . $template);
		View::assign('params', $params);
		return $filename;
	}

	public static function getTemplateInfo(string $type, string $name): ?array
	{
		if (!isset(self::$templateTypes[$type])) {
			return null;
		}
		$infoFile = TEMPLATE_ROOT . $type . DIRECTORY_SEPARATOR . $name . DIRECTORY_SEPARATOR . 'info.json';
		if (!is_file($infoFile)) {
			return null;
		}
		$json = json_decode(file_get_contents($infoFile), true);
		if (!is_array($json)) {
			return null;
		}
		return $json;
	}
}
