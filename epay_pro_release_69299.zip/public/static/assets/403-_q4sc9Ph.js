const e=""+new URL("403-BdWuHcJA.svg",import.meta.url).href;export{e as i};
