import{p as t}from"./index-CNLvmvsZ.js";function e(){return t.get({url:"./update/checkUpdate"})}function r(){return t.post({url:"./update/doUpdate",timeout:3e5})}export{r as a,e as f};
