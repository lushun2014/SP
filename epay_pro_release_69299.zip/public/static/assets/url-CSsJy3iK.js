function n(){const n="./";return n.endsWith("/")?n:".//"}export{n as g};
