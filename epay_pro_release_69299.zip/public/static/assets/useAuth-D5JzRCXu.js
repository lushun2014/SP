import{u as i}from"./index-DBdn_74r.js";i();
