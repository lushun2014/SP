<?php
define('API_INIT_OLD', true);
$_GET['s'] = 'api/pay/submit';

require __DIR__ . '/index.php';