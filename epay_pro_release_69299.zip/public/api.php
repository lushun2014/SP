<?php
$_GET['s'] = 'api/obsolete';

require __DIR__ . '/index.php';