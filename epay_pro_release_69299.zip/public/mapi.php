<?php
define('API_INIT_OLD', true);
$_GET['s'] = 'api/pay/create';

require __DIR__ . '/index.php';